#pragma once

namespace Enums {
	enum class FigureType { Line, Triangle, Rectangle };
}