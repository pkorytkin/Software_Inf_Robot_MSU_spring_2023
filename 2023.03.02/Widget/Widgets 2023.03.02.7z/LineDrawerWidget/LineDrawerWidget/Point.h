struct Point{
	int X;
	int Y;
};